/*
 * DC_MOTOR.h
 *
 * Created: 2019/3/1 12:32:33
 *  Author: Virtual
 */ 


#ifndef DC_MOTOR_H_
#define DC_MOTOR_H_
#define F_CPU 16000000UL
#include <avr/io.h>

void io_init (void);
void init_timer0 (void);
void delay_msec (uint16_t circulation);

void timer3_init(void);
void fast_PWM (uint16_t duty_cycle);
void fast_PWM_2(uint16_t duty_cycle);

#endif /* DC_MOTOR_H_ */