/*
 * Supercapcitor.c
 *
 * Created: 2019/3/24 3:28:33
 * Author : Virtual
 */ 

#include "DC_MOTOR.h"


int main(void)
{	io_init ();
	timer3_init();
    
	
    while (1) 
    {
		switch(PINA & 0x03)
		{
			case 0x01:
				fast_PWM(84); //212/255 = 0.83, choose 84% duty cycle
				break;
			
			case 0x02:
				fast_PWM_2(99);
				break;
			
			default:
				fast_PWM(0);
				fast_PWM_2(0);
		}
		
		
	}
	
}

