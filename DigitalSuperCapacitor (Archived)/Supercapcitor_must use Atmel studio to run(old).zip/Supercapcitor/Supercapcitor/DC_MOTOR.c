/*
 * DC_MOTOR.c
 *
 * Created: 2019/3/1 12:32:06
 *  Author: Virtual
 */ 

/*
 * timer.c
 *
 * Created: 2019/2/21 12:09:01
 *  Author: Virtual
 */ 

#include "dc_motor.h"

void io_init (void)
{
	
	DDRE = (1 << PE3) | (1 << PE4); //OC3A and OC3B
	PORTE = ~((1 << PE3) | (1 << PE4)); //output of OC3A and OC3B
	
	DDRA = 0x00; //port A as input
	PORTA = 0xFF; //standby
}


	
void init_timer0 (void)
{
	TCNT0 = 240;// prescale 1024, 16000000/1024 = 15625, 1ms * 15625 = 15.625 = 16, 256 - 16 = 240
	TCCR0A = 0x00; //normal operation
	TCCR0B = 0x00;//normal operation 
}

void delay_msec (uint16_t circulation)
{
	uint16_t i;
	for(i = 0; i < circulation; i++) //for circulation
	 {
		TCCR0B = (1 << CS02)|(1 << CS00); // prescale 1024
		while ((TIFR0 & (1 << TOV0)) == 0);
		{
		
		}//waiting overflow
		TCCR0B = 0; //turn off timer
		TIFR0 = (1 << TOV0); //overflow bit set back to 1
		TCNT0 = 240; //count from 240
	}
}

void timer3_init(void)
{
	//counter reset
	TCNT3 = 0;

	//Fast PWM, 10-bit mode for timer3
	TCCR3A = (1 << WGM30) | (1 << WGM31);
	TCCR3B = (1 << WGM32);
	//converting for timer3 and reset counter
	TCCR3A = TCCR3A | (1 << COM3A1); //OCR3A
	TCCR3A = TCCR3A | (1 << COM3B1); //OCR3B
	
}

void fast_PWM (uint16_t duty_cycle)
{
	OCR3A = 1023 *(uint32_t)duty_cycle/100; //set the duty cycle value
	
	//prescale for timer3
	TCCR3B = TCCR3B | (1 << CS32); //prescale 256
	
}

void fast_PWM_2(uint16_t duty_cycle)
{

	OCR3B = 1023 *(uint32_t)duty_cycle/100; //set the duty cycle value
	TCCR3B = TCCR3B | (1 << CS32); //prescale 256
}



